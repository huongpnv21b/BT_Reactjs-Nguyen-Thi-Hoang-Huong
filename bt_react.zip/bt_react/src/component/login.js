import React, { Component } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {Redirect} from 'react-router-dom';
class Login extends Component{
    constructor(props){
        super(props);
        this.state = {
            username : '',
            password : '',
            loggedIn : false,
        }
    }
    onChange = (event) =>{
      var target =event.target;
      var name =target.name;
      var type =target.type;
      var value =target.value;


      this.setState({
        [name] : value,
      });
    }
    onLogin = (e) =>{
    	e.preventDefault();
    	var { username, password } = this.state;
    	if ( username === 'huong' && password === '123') {
        this.setState({loggedIn : true})
        localStorage.setItem('username', username);      		
    	}else{
    		 toast.error("Sai tên đăng nhập hoặc mật khẩu !", {
      }) 
    }
    }
    render(){
        var { username, password } = this.state;
        if (this.state.loggedIn) {
          toast.success("Đăng nhập thành công", {
        })
        return <Redirect to="/display"/>;
      }
        return(
            <div >
                <title>login</title>
                <link rel="stylesheet" type="text/css" href="style.css" />
                <form onSubmit = {this.onLogin}>
                <div className="login">
                    <div className="texta">
                    <h1>Login</h1>
                    </div>
                    <div className="main">
                    <form>
                        <input type="text" class="w3-input"  placeholder="Username" name="username" value ={ this.state.username }   onChange ={this.onChange} required />
                        <br />
                        <input type="password" class="w3-input" placeholder="password" name="password" value ={ this.state.password }   onChange ={this.onChange} required/>
                        <br />
                        <h6 style={{ textAlign:'center',color:'blue'}}>Forgot My Password</h6>
                        <br />
                        <button  className="btnLogin" >Login</button>
                    </form>
                    </div>
                </div>
                </form>
            </div>
        )
    }
}
export default Login;