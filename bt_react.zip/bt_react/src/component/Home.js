import React, { Component } from 'react';
import Axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Link, NavLink } from 'react-router-dom';

class Home extends Component {
    constructor(props){
      
        super(props)
        this.state={
            products:[],
            keyword:"",
        }
      
    }
    
    componentDidMount(){
        Axios({
            methos:'GET',
            url:"http://localhost:3000/products?_limit=10",
            data:null
        }).then (res=>{
            this.setState({
                products:res.data
            });
        }).catch(err=>{
            console.log(err);
        });
        }
       
    render() {
        var products=this.state.products;
        return (
           // <div style={{display: "flex", padding:"20px"}} >
           <div class="row" > 
             {
                products.map((product,index)=>
                <Item 
                    key={index} product={product}
                    onDelete={this.onDeleted}
                ></Item>
                )}
        </div>
         );
    }
}


class Item extends Component {

    
    render(props) {
        return (
           // <div className="card" style={{width: '400px', marginRight:"20px"}}>
           <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" >
               {/* className="card-img-top" */}
                <img className="card-img-top" src={this.props.product.avatar} alt="Card image" />
                <div className="card-body" style ={{marginLeft:"40px"}}>
                <h4 className="card-title" style={{color:"red"}}>{this.props.product.name}</h4>
                <p className="card-text"><h6> {this.props.product.price} vnd</h6> </p>
                <a className="add-to-cart pull-left"><i className="fa fa-shopping-cart" /></a>
               
                <NavLink to={`/products/${this.props.product.id}/cart`}  >
                <button onClick={this.onAdd} ><img style ={{ marginRight:"20px",marginLeft:"20px"}}src="/Image/cart.png"></img></button>
                </NavLink>
                <NavLink to={`/products/${this.props.product.id}/productdetail`}>
                <a href="#" className="btn btn-info">Detail</a>
                </NavLink>
                </div>
            </div>
        );
    }
}
  
  export default Home;