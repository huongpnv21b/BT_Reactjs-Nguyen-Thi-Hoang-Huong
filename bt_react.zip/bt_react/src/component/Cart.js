import React, { Component } from 'react';


import axios from 'axios';
// import Slide from './layout_page/Slide.js';
// import Header from './layout_page/Header.js';
// import Footer from './layout_page/Footer.js';
// import { NavLinks } from 'react-router-dom';
class Cart extends Component {
	constructor(props){
        super(props)
        this.state = {
           carts : []
        }
    }    
    
    componentDidMount(){
      var {match} = this.props;
      if (match) {
      	var id = match.params.id;
      	axios({
        method: 'GET',
        url :`http://localhost:3000/products/${id}`,
        data : null
     	 }).then(res =>{
     	 	var data =res.data;
        	this.setState({
         	 carts :res.data
        	});
      		}).catch( err =>{
        	console.log(err);
      		});
    	}
      }
      finIndex=(carts, id)=>{
          var {carts}=this.state;
          var result=-1;
          carts.forEach((products,index)=>{
              if(products.id === id){
                  result=index;
              }
          });
          return result;
      }
 render() {
   var {carts} = this.state;
   var cart=[];
  //  cart=push(carts);
  //  var addCart=.push({cart});
  	return (
      <React.Fragment>
        {/* <Header /> */}
        <table class="table table-sm">
            <thead>
              <tr>  
                <th scope="col">Avatar</th>
                <th scope="col">Name</th>
                <th scope="col">price</th>
                <th scope="col">Quantity</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row"><img style={{ width:"70px"}} src={this.state.carts.avatar} alt="Card image" /></th>
                <td>{this.state.carts.name}</td>
                <td>{this.state.carts.price}</td>
                <td>{this.state.carts.d}</td>
              </tr>
            </tbody>
          </table>
        
        {/* <Footer />     */}
        </React.Fragment>
   		);
	}
}



export default Cart;