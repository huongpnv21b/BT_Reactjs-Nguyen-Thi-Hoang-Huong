import React, { Component } from 'react';
import Axios from 'axios';

class Footer extends Component{
    render(){
        return(
             <footer className="page-footer font-small unique-color-dark">
        <ul>
          <li>
            <img className="icon" style={{ width:"90px",height:"70px"}} src="Image/logo.png" ></img>
            <div className="text">
              <h4>About</h4>
              <div>San Pham cua shop hiện đang nhập khẩu các nguyên liệu chất lượng tại thị trường Châu Âu.Từ đó san phẩm được chế tạo  đặc biệt chất lượng , đưa các sản phẩm đến tay người tiêu dùng an toàn , và đặc biệt độ bền và chất lương tại shop của chúng tôi.Phục vụ tận tình đến khách hàng . <a href="#">Read more</a></div>
            </div>
          </li>
          <li>
            <img className="icon" style={{ width:"90px",height:"70px"}}src="Image/paper.png"></img>
            <div className="text">
              <h4>6 reason-choose shop </h4>
              
              {/* <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Read more</a></div> */}
              <span>-  Hàng ngàn mẫu có sẵn tại Shop Đà Nẵng </span><br></br>
              <span>-  Giá bán lẻ luôn luôn thấp</span><br></br>
              <span>-  Cam kết nhồi 100% bông sạch</span><br></br>
              <span>-  Miễn phí ship hàng khi mua lần 3</span><br></br>
              <span>-  Giao hàng toàn quốc</span><br></br>
              <span>-  Bảo hàng Gấu 1 năm</span> 

             
            </div>
          </li>
          <li>
            <img  className="icon"  src="Image/contact.png" />
            <div className="text">
              <h4>Contact</h4>
              <p>
                <img style={{width: '30px'}} className="icon" src="Image/address.png" /> <p style ={{ marginLeft:"20"}}>101B Le Huu Trac, Son Tra, Da Nang</p></p>
              <p>
                <img className="icon" src="Image/gmail.png"/>  <p style ={{ marginLeft:"10px"}}> info@example.com</p></p>
              <p>
                <img className="icon"src="Image/phone.png" /> + 01 234 567 88</p>
              <p>
                <i className="icon"src="Image/phone.png" /> &nesp;  + 01 234 567 89</p>
            </div>
          </li>
        </ul>
        <div className="bar">
          <div className="bar-wrap">
            <ul className="links">
              <li><a href="#">Home</a></li>
              <li><a href="#">License</a></li>
              <li><a href="#">Contact Us</a></li>
              <li><a href="#">Advertise</a></li>
              <li><a href="#">About</a></li>
            </ul>
            <div className="social">
              <a href="#" className="fb">
                <span data-icon="f" className="icon" />
                <span className="info">
                  <span className="follow">Become a fan Facebook</span>
                  <span className="num">9,999</span>
                </span>
              </a>
              <a href="#" className="tw">
                <span data-icon="T" className="icon" />
                <span className="info">
                  <span className="follow">Follow us Twitter</span>
                  <span className="num">9,999</span>
                </span>
              </a>
              <a href="#" className="rss">
                <span data-icon="R" className="icon" />
                <span className="info">
                  <span className="follow">Subscribe RSS</span>
                  <span className="num">9,999</span>
                </span>
              </a>
            </div>
            <div className="clear" />
            <div className="copyright">©  2014 All Rights Reserved</div>
          </div>
        </div>
      </footer>
        )
    }
}
export default Footer;  



