import React, { Component } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, NavLink } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';

import 'react-toastify/dist/ReactToastify.css';
export default class Update extends Component {
    constructor(props) {
        super(props);
        

        this.state = {
            id: '',
            name: '',
            price: '',
            quantity:'',
            avatar:'',
            material:'',
            origin:''
        }
    }
    
    componentDidMount(){
        var {match} = this.props;
        if (match) {
          var id = match.params.id;
          axios({
          method: 'GET',
          url :`http://localhost:3000/products/${id}`,
          data : null
         }).then(res =>{
          var data =res.data;
            this.setState({
              id: data.id,
              name : data.name,
              price : data.price,
              quantity: data.quantity,
              avatar : data.avatar,
              material:data.material,
              origin:data.origin
            });
          }).catch( err =>{
        });
       }
      }
      onChange = (event) =>{
        var target =event.target;
        var name =target.name;
        var type =target.type;
        var value =target.value;
        if (type === 'file') {
          value = this.avatar.value.replace(  /C:\\fakepath\\/i, "/Image/images/" );
        }
  
        this.setState({
          [name] : value,
        });
      }

      onSave =(e) =>{
    	e.preventDefault();
    	var { id, name, price,quantity, avatar, material, origin} = this.state;
      var {history} = this.props;
      if (id) {
        axios({
        method: 'PUT',
        url :`http://localhost:3000/products/${id}`,
        data : {
            name : name,
            price : price,
            avatar : avatar,
            quantity: quantity,
            material: material,
            origin:origin
            
          }
        }).then(res =>{
              toast.success("Cập nhật sản phẩm thành công", {
          })
            history.goBack();
        });
      }
    } 
    onClear = () =>{
        this.setState({
              name : '',
              price : '',
              avatar : '',
              quantity: '',
              material:'',
              origin:''
        });
      }
    render() {         
        var { id, name, price, avatar , quantity} = this.state;
        return (
            <div style={{marginTop: 10}}>
                <h3>EDIT Product</h3>
                <div className="panel panel-warning col-md-8 ml">
              <div className="container">
              <div className="panel-body mt-4">
                <form onSubmit = {this.onSave}>
                  <div className="form-group">
                    <label>Tên Sản phẩm :</label>
                    <input type="text" name="name" value ={this.state.name} onChange ={this.onChange} className="form-control" />
                  </div>
                  <div className="form-group">
                    <label>Giá Sản phẩm ($) :</label>
                    <input type="number" name="price" value ={this.state.price} onChange ={this.onChange} className="form-control" />
                  </div>
                  
                  <div className="form-group">
                    <label>So luong :</label>
                    <input type="number" name="quantity" value ={this.state.quantity} onChange ={this.onChange} className="form-control" />
                  </div>
                  <div className="form-group">
                    <label>Nguyen Lieu :</label>
                    <input type="text" name="material" value ={this.state.material} onChange ={this.onChange} className="form-control" />
                  </div>
                  <div className="form-group">
                    <label>Xuat Xu:</label>
                    <input type="text" name="origin" value ={this.state.origin} onChange ={this.onChange} className="form-control" />
                  </div>
                  <div className="form-group">
                    <label>Chọn Ảnh :</label>
                    <input type="file" name="avatar" ref ={ (input) => { this.avatar = input} } onChange ={this.onChange} className="form-control" />
                  </div>
                  <br />
                  <div className="text-center">
                    <button type="submit"  className="btn btn-primary">Lưu</button>&nbsp;
                    <button type="button" onClick={this.onClear} className="btn btn-primary">Clear</button>
                    <NavLink to="/display" className="btn btn-primary ml-1">Trở về</NavLink>
                  </div>
                </form>
              </div>
              </div>
              
            </div>
            </div>
        )
    }
}
// export default Add;