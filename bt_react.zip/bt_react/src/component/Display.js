import React, { Component } from 'react';
import Axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Link } from 'react-router-dom';

class Display extends Component {
    constructor(props){
        super(props)
        this.state={
            products:[],
            keyword:"",
        }
    }
    componentDidMount(){
        Axios({
            methos:'GET',
            url:"http://localhost:3000/products",
            data:null
        }).then (res=>{
            this.setState({
                products:res.data
            });
        }).catch(err=>{
            console.log(err);
        });
        }
        onDeleted=(id)=>{
            console.log(id);
            var{products}=this.state;
            Axios({
                method:'DELETE',
                url:`http://localhost:3000/products/${id}`,
                data:null
            }).then(res =>{
                if(res.status ===200){
                    var index=this.finIndex(products,id);
                    if(index !== -1){
                        products.splice(index,1);
                        this.setState({
                            products:products
                        });
                        toast.success("Xoa san pham thanh cong",{
    
                        })
                    }
                }
            });
            
        }
        
        
        finIndex=(products, id)=>{
            var {products}=this.state;
            var result=-1;
            products.forEach((product,index)=>{
                if(product.id === id){
                    result=index;
                }
            });
            return result;
        }
    render() {
        var products=this.state.products;
        return (
            <div>
                <h2 style={{ marginLeft:'400px', color:'black',textShadow:'2px 2px 2px #cc0000',fontsize:'40px',fontweight: 'bold'}}> Danh sach san pham </h2>
                <table class="table">
                <thead class="thead-dark">
                    <tr>
                       
                        <th scope="col">STT</th>
                        <th scope="col">Name Product</th>
                        <th scope="col">Price</th>
                        <th scope="col">Avartar</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Action</th>
                    </tr>
                   </thead>
                {
                products.map((product,index)=>
                <Item 
                    key={index} product={product}
                    onDelete={this.onDeleted}
                ></Item>
                // <p> {product.price}</p>  
                )}</table>
            </div>
        );
    }
}


class Item extends Component {

    
    render(props) {
        return (
            <tbody>
            <tr>
                <td>{this.props.product.id}</td>
                <td>{this.props.product.name}</td>
                <td>{this.props.product.price}</td>
                <td><img style={{ width:"70px"}} src={this.props.product.avatar} alt="Card image" /></td>
                <td>{this.props.product.quantity}</td>
                <td><button  className="btn btn-danger" type="submit" onClick ={ () =>this.props.onDelete(this.props.product.id)}>Delete</button>
                <Link to={"/update/"+this.props.product.id} className="btn btn-primary">Edit</Link></td>
            </tr>
            </tbody>
        
        );
    }
}

export default Display;