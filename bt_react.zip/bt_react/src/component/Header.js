import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
class Header extends Component{
    Logout = () =>{
        localStorage.clear();
        toast.success("Đăng xuất thành công", {
        })
      }
    render(){
        return (
            <div className="head">
                <div className="logo">
                <a onclick="displayProduct()"><img className="logo" src="Image/logo.png" /></a>
                </div>
                <div>
                <center>
                    <input id="search" className="search" type="text" placeholder="search..." name defaultValue size={70} />
                    <button className="res" onclick="research()"><img id="s" src="Image/search.png" /></button>
                </center>
                </div> 
                <div>
                <NavLink  onClick={this.Logout} to="/home"> 
                    <button><img></img>Loout</button>
                </NavLink>
                <NavLink to="/login"> 
                    <button><img></img>Login</button>
                </NavLink>
                </div>
                <div className="cart">
                <NavLink to="/products/:id/cart">
                    <button>
                        <img src="Image/cart.png" />
                        <b id="sl" />
                    </button>
                </NavLink>
                </div>
            </div>
        )
    }
}

export default Header;