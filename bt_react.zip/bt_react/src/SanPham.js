import React, { Component } from 'react';
import Axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
class SanPham extends Component {
    constructor(props){
        super(props)
        this.state={
            products:[],
            keyword:"",
        }
    }
    componentDidMount(){
        Axios({
            methos:'GET',
            url:"http://localhost:3000/product",
            data:null
        }).then (res=>{
            this.setState({
                products:res.data
            });
        }).catch(err=>{
            console.log(err);
        });
        }
        onDeleted=(id)=>{
            console.log(id);
            var{products}=this.state;
            Axios({
                method:'DELETE',
                url:`http://localhost:3000/product/${id}`,
                data:null
            }).then(res =>{
                if(res.status ===200){
                    var index=this.finIndex(products,id);
                    if(index !== -1){
                        products.splice(index,1);
                        this.setState({
                            products:products
                        });
                        toast.success("Xoa san pham thanh cong",{
    
                        })
                    }
                }
            });
            
        }
        
        onAddProduct
        finIndex=(products, id)=>{
            var {products}=this.state;
            var result=-1;
            products.forEach((product,index)=>{
                if(product.id === id){
                    result=index;
                }
            });
            return result;
        }
    render() {
        var products=this.state.products;
        return (
            <div>
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <a class="navbar-brand" href="#">Navbar</a>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                        <div class="navbar-nav">
                        <a class="nav-item nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
                        <a class="nav-item nav-link" href="#">Them</a>
                        <a class="nav-item nav-link" href="#">Update</a>
                        <a class="nav-item nav-link disabled" href="#">About</a>
                        </div>
                    </div>
                </nav>
                <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">STT</th>
                        <th scope="col">Name Product</th>
                        <th scope="col">Price</th>
                        <th scope="col">Avartar</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Action</th>
                    </tr>
                   </thead>
                {
                products.map((product,index)=>
                <Item 
                    key={index} product={product}
                    onDelete={this.onDeleted}
                ></Item>
                // <p> {product.price}</p>  
                )}</table>
            </div>
        );
    }
}


class Item extends Component {

    
    render(props) {
        return (
            <tbody>
            <tr>
                <td>{this.props.product.id}</td>
                <td>{this.props.product.name}</td>
                <td>{this.props.product.price}</td>
                <td>{this.props.product.avartar}</td>
                <td>{this.props.product.quantity}</td>
                <td><button type="submit" onClick ={ () =>this.props.onDelete(this.props.product.id)}>Delete</button></td>
            </tr>
            </tbody>
        
        );
    }
}

export default SanPham;