import React, { Component } from 'react'
import logo from './logo.svg';
// import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import Add from './component/Add.js';
import Login from './component/login.js';
import Header from './component/Header.js'
import Slide from './component/Slide.js'
 import Home from './component/Home.js';
 import Footer from './component/Footer.js';
import Update from './component/Update.js';
import Display from './component/Display.js';
import ProductDetail from './component/ProductDetail';
import Cart from './component/Cart.js';


class App extends Component {
  render() {
    return (
      <Router>
        <Header></Header>
        <Slide></Slide>
        <div className="container">
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item">
                  <Link to={'/home'} className="nav-link">Home</Link>
                </li>
                <li className="nav-item">
                  <Link to={'/add'} className="nav-link">Add</Link>
                </li>
                <li className="nav-item">
                  <Link to={'/display'} className="nav-link">Display</Link>
                </li>
              </ul>
            </div>
          </nav> <br/>
          <h2>Welcome to My WebSite</h2> <br/>
          
          <Switch>

               <Route exact path='/' component={ Home } /> 
              <Route path='/products/:id/productdetail' component={ ProductDetail } />
              <Route path='/products/:id/cart' component={ Cart } />
              <Route path='/add' component={ Add } />
              <Route path='/add' component={ Add } />
              <Route path='/login' component={ Login } />
              <Route path='/home' component={ Home } />
              <Route path='/update/:id' component={ Update } />
              <Route path='/display' component={ Display } />
          </Switch>
         
        </div>
        <Footer></Footer>
      </Router>
    );
  }
}

export default App;

